import { useState } from 'react'
import Card from './Components/Card'


function App() {
 
  return (
    <>
     <Card />
    </>
  )
}

export default App
